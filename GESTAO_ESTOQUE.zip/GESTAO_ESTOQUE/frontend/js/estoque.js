let contadoresPorCategoria = {}; // Objeto para armazenar contadores por categoria

function gerarCodigoDeBarras(categoria) {
    // Inicializa o contador para a categoria se ainda não existir
    if (!contadoresPorCategoria[categoria]) {
        contadoresPorCategoria[categoria] = 1;
    }

    // Formata o código de barras
    const codigo = `${categoria}${String(contadoresPorCategoria[categoria]).padStart(5, '0')}`;
    
    // Incrementa o contador para a próxima vez que essa categoria for cadastrada
    contadoresPorCategoria[categoria]++;
    
    return codigo;
}

function mostrarNotificacao(codigoDeBarras) {
    const notification = document.getElementById('notification');
    notification.textContent = `O lote ${codigoDeBarras} foi cadastrado com sucesso!`; // Mensagem da notificação
    notification.style.display = 'block'; // Mostra a notificação

    // Oculta a notificação após 3 segundos
    setTimeout(() => {
        notification.style.display = 'none';
    }, 3000);
}

// Script para manipular o formulário
document.getElementById('produtoForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    // Obtém os valores dos campos do formulário
    const nome = document.getElementById('nome').value;
    const categoria = document.getElementById('categoria').value;
    const quantidade = document.getElementById('quantidade').value;
    const preco = document.getElementById('preco').value;
    const dataDeValidade = document.getElementById('dataDeValidade').value;
    const dataDeFabricacao = document.getElementById('dataDeFabricacao').value;

    // Gera o código de barras
    const codigoDeBarras = gerarCodigoDeBarras(categoria);
    document.getElementById('codigoDeBarras').value = codigoDeBarras; // Exibe o código de barras no campo

    // Cria uma nova linha na tabela
    const table = document.getElementById('produtosTable').querySelector('tbody');
    const newRow = table.insertRow();

    newRow.innerHTML = `
        <td>${nome}</td>
        <td>${categoria}</td>
        <td>${quantidade}</td>
        <td>${parseFloat(preco).toFixed(2)}</td>
        <td>${dataDeValidade}</td>
        <td>${dataDeFabricacao}</td>
        <td>${codigoDeBarras}</td>
    `;

    // Limpa o formulário
    document.getElementById('produtoForm').reset();

    // Mostra a notificação
    mostrarNotificacao(codigoDeBarras);
});

