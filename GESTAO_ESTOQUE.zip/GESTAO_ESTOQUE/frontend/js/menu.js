// Seleciona o botão e o menu
const btnExpandir = document.querySelector('.btn-expandir');
const menuLateral = document.querySelector('nav.menu-lateral');
const mainContainer = document.querySelector('.main-container');

// Verifica se o estado do menu está salvo no localStorage
const isMenuExpandido = localStorage.getItem('menuExpandido') === 'true';
if (isMenuExpandido) {
    menuLateral.classList.add('expandido');
    mainContainer.style.marginLeft = '320px'; // Tamanho do menu expandido
} else {
    mainContainer.style.marginLeft = '80px'; // Tamanho do menu recolhido
}

// Função para alternar o estado do menu
function toggleMenu() {
    menuLateral.classList.toggle('expandido');
    if (menuLateral.classList.contains('expandido')) {
        mainContainer.style.marginLeft = '300px'; // Tamanho do menu expandido
    } else {
        mainContainer.style.marginLeft = '80px'; // Tamanho do menu recolhido
    }
    // Salva o estado atual do menu no localStorage
    localStorage.setItem('menuExpandido', menuLateral.classList.contains('expandido'));
}

// Adiciona evento de clique ao botão de expandir
if (btnExpandir) {
    btnExpandir.addEventListener('click', toggleMenu);
}

// Seleciona todos os itens do menu
const menuItems = document.querySelectorAll('.item-menu a');

// Pega o caminho atual da URL
const currentPath = window.location.pathname.split('/').pop();

// Função para destacar o item ativo
function highlightCurrentMenuItem() {
    menuItems.forEach(function(item) {
        const menuItemPath = item.getAttribute('href');
        if (menuItemPath === currentPath) {
            item.parentElement.classList.add('ativo');
        } else {
            item.parentElement.classList.remove('ativo'); // Remove a classe ativo dos outros itens
        }
    });
}

// Chama a função de destaque ao carregar a página
highlightCurrentMenuItem();
