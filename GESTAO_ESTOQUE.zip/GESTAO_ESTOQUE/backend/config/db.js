import mysql from "mysql"

export const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "PRO-2153-084-0716-057#pro",
    database: "crud"
})