// backend/models/produto.js

const db = require('../config/db'); // Importa a conexão com o banco de dados

// Função para criar um novo produto
const criarProduto = (nome, preco, quantidade) => {
  const query = 'INSERT INTO produtos (nome, preco, quantidade) VALUES (?, ?, ?)';
  return new Promise((resolve, reject) => {
    db.query(query, [nome, preco, quantidade], (err, results) => {
      if (err) {
        return reject(err);
      }
      resolve(results.insertId); // Retorna o ID do novo produto
    });
  });
};

// Função para buscar todos os produtos
const buscarProdutos = () => {
  const query = 'SELECT * FROM produtos';
  return new Promise((resolve, reject) => {
    db.query(query, (err, results) => {
      if (err) {
        return reject(err);
      }
      resolve(results);
    });
  });
};

// Exporta as funções
module.exports = { criarProduto, buscarProdutos };
